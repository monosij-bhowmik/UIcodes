function admissionFormCheck(){
  
        var fullName, contact, email,course;
        fullName = document.getElementById("form34").value;
        email = document.getElementById("form29").value;
        contact = document.getElementById("form20").value;
        course=document.getElementById("CoursesDropDown").value;
        
        if(!fullName || !email || !contact){
            alert("Please fill all necessary fields");
        }
        else if(course=="Select Department")
        {
            alert("Please select course");
        }
        else if(contact.length!=10)
        {
            alert("Please enter 10 digit mobile number");
        }
        else {
            alert("Form submitted successfully");
            document.getElementById("admissionForm").reset();
            
        }
      }